import Thorium , { View , Style , Prototype , UserInterface , Controller , Components} from '../src/index';
import Mutations from '/Users/guillaume/Documents/github/Types/Mutations/src/mutation';
import useState from '/Users/guillaume/Documents/github/Types/States/src/';

const clock = new class Clock extends Components.Div<Controller>{
  constructor(){

    const [loaded,setloaded] = useState<boolean>(false);
    const [count,addCount] = useState<number>(0);

    super({
      prop : {
        name : 'clock',
        class : 'clock',
        'loaded' : loaded.value,
        'count' : count.value,
        'timer' : ''
      },
      proto : {
        AfterInitialise(){

          const observer = Mutations.Observe(this , { attributes : true , attributeFilter : ['loading' , 'timer']} , (mutations) => {

            const {
              type:type,
              attributeName:name,
              target:target
            } = (mutations as MutationRecord[])[0];

            const loadingStatus = this.getAttribute('loaded');

            if(name == 'timer' && loadingStatus == "true")this.innerHTML = `<p>${this.getAttribute(name)}</p>`;

          });

          console.log(`observerId : ${observer?.id}`);

          setInterval(() => {

            const date = new Date();
            this.setAttribute('count' , addCount(count.value + 1));
            this.setAttribute('timer' , `${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`);
          } , 1000);

          setTimeout(() => {
            this.setAttribute('loaded' , setloaded(true));
          } , 1000)
        }
      }
    })
  }
}()

const App = new class App extends Components.App<Controller>{

  constructor(){
    super({
      prop : {
        id : 'app'
      },
      childrens : [clock]
    })
  }

}

const AppView = class AppView extends View.View{

  constructor(){
    super(App as any);
  }

}

Thorium.Vue(AppView).Show();
